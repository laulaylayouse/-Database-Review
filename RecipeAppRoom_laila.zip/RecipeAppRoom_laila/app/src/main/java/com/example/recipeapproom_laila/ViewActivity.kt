package com.example.recipeapproom_laila

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ViewActivity : AppCompatActivity() {

    lateinit var Recycler_View: RecyclerView

    val Recipes_list = arrayListOf<Table_Recipes>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view)
        supportActionBar?.hide()

        Recycler_View = findViewById(R.id.Recycler_View)
        Recycler_View.adapter = Adapter(this, Recipes_list)
        Recycler_View.layoutManager = LinearLayoutManager(applicationContext)


        Recipes_list.clear()
        Recipes_list.addAll(RecipesDatabase.getInstance(applicationContext).recipesDao().getAllRecipes())
        Recycler_View.adapter!!.notifyDataSetChanged()

    }
    fun Recipes_Details() {
        Recipes_list.clear()
        Recipes_list.addAll(RecipesDatabase.getInstance(applicationContext).recipesDao().getAllRecipes())
        Recycler_View.adapter!!.notifyDataSetChanged()
    }

}