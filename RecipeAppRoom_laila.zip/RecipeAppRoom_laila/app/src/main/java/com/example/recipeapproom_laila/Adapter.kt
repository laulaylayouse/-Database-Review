package com.example.recipeapproom_laila

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_update_delete.view.*
import kotlinx.android.synthetic.main.item_row.view.*
import kotlinx.android.synthetic.main.item_row.view.TextView_Title

class Adapter(val activity:ViewActivity, val messages: ArrayList<Table_Recipes> ) :
    RecyclerView.Adapter<Adapter.ItemViewHolder>() {
    class ItemViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        return ItemViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.item_row,
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val message = messages[position]

        holder.itemView.apply {
            TextView_id.text = message.id.toString()
            TextView_Title.text = "Title: ${message.title}"
            TextView_Author.text = "Author: ${message.author}"
            TextView_Ingredents.text = "Ingredents: ${message.ingredients}"
            TextView_Instruction.text = "Instruction: ${message.instructions}"

            ImageView_more.setOnClickListener {
                val builder = AlertDialog.Builder(context)
                val dialogView =
                    LayoutInflater.from(context).inflate(R.layout.activity_update_delete, null)
                builder.setView(dialogView)
                val alertDialog: AlertDialog = builder.create()

                TextView_id.text = message.id.toString()
                dialogView.EditText_Title_update_delete.setText("Title: ${message.title}")
                dialogView.EditText_Author_update_delete.setText("Author: ${message.author}")
                dialogView.EditText_Ingredents_update_delete.setText("Ingredents: ${message.ingredients}")
                dialogView.EditText_Instruction_update_delete.setText("Instruction: ${message.instructions}")

                dialogView.Button_Update.setOnClickListener {
                    val title = dialogView.EditText_Title_update_delete.text.toString()
                    val author = dialogView.EditText_Author_update_delete.text.toString()
                    val ingredients = dialogView.EditText_Ingredents_update_delete.text.toString()
                    val instructions = dialogView.EditText_Instruction_update_delete.text.toString()
                    if(title.isNotEmpty()&&author.isNotEmpty()&&ingredients.isNotEmpty()&&instructions.isNotEmpty()){
                        RecipesDatabase.getInstance(activity).recipesDao().updateRecipe(Table_Recipes(message.id,title,author, ingredients, instructions))
                        Toast.makeText(context,"Recipe is Updated",Toast.LENGTH_SHORT).show()
                        activity.Recipes_Details()
                        alertDialog.dismiss()
                    }else
                    {
                        Toast.makeText(context,"Please write all Details!!",Toast.LENGTH_SHORT).show()
                    }

                }
                dialogView.Button_Delete.setOnClickListener {
                    val Builder = androidx.appcompat.app.AlertDialog.Builder(context)
                    Builder.setTitle("Delete Recipe ${message.id}")
                    Builder.setMessage("Are you sure you want to delete recpie ${message.id}?")

                    Builder.setPositiveButton("Delete") { dialogInterface, which ->
                        RecipesDatabase.getInstance(activity).recipesDao().deleteRecipe(Table_Recipes(message.id,message.title,message.author,message.ingredients,message.instructions))
                        activity.Recipes_Details()
                        Toast.makeText(context,"Recipe is Deleted",Toast.LENGTH_SHORT).show()
                        alertDialog.dismiss()
                        dialogInterface.dismiss()

                    }
                    builder.setNegativeButton("Cancel") { dialogInterface, which ->
                        dialogInterface.dismiss()
                    }
                    val alertDialog: androidx.appcompat.app.AlertDialog = Builder.create()
                    alertDialog.setCancelable(false)// to show cancel button
                    alertDialog.show()
                }
                alertDialog.getWindow()?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                alertDialog.setCancelable(true)
                alertDialog.show()
            }
        }


    }

    override fun getItemCount() = messages.size

}
