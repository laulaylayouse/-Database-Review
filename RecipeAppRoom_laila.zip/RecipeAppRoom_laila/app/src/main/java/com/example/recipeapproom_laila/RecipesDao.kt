package com.example.recipeapproom_laila

import androidx.room.*

@Dao
interface RecipesDao {

    @Query("SELECT * FROM Recipes ")
    fun getAllRecipes(): List<Table_Recipes>
    @Insert
    fun insertRecipe(recipe: Table_Recipes)
    @Update
    fun updateRecipe(recipe: Table_Recipes)
    @Delete
    fun deleteRecipe(recipe: Table_Recipes)

}